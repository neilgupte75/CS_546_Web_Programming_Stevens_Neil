const ObjectId = require('mongodb').ObjectID;
const posts=require("./posts")
const animals=require("./animals")

let addLikes=async(animId,postId)=>{
    const postsent = await posts.getPostById(postId);
    const userThatPosted = await animals.get(animId);
    if(userThatPosted.likes===postsent._id){
        return 
    }
    animals.addLikeToUser(animId,postId);
    return
}
module.exports={addLikes};