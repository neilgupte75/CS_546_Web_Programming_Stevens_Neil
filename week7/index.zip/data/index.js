const postData = require("./posts");
const animalsData = require("./animals");
const likesData= require("./likes")
module.exports = {
  animals: animalsData,
  posts: postData,
  likes:likesData
};