const express = require('express');
const router = express.Router();
const likesData = require('../data/likes');


router.post('/:id', async (req, res) => {
    try {
      const post = await likesData.addLikes(req.params.id,req.query.postId);
      res.json(post);
      res.sendStatus(200);
    } catch (e) {
      res.status(404).json({error: 'Post not found'});
    }
  });

  router.delete('/:id', async (req, res) => {
    try {
      const post = await likesData.removeLikes(req.params.id,req.query.pid);
      res.json(post);
      res.sendStatus(200);
    } catch (e) {
      res.status(404).json({error: 'Post not found'});
    }
  });


  module.exports=router;
  