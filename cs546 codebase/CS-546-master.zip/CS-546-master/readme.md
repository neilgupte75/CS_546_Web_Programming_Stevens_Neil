# Welcome to CS-546!

## Current Semester: Summer 2019 A / B

## In Person

## Webcampus (CS-546-WS)

CS-546-WS will run on Fridays during the Summer Schedule, with Lecture 1 on Friday, May 25th and Lecture 14 on {TBD}.

### Slack

Slack Communication for CS-546-WS may only be done on the CS-546-554-WS Slack Room.

Currently, Slack is not allowing me to create a chatroom.