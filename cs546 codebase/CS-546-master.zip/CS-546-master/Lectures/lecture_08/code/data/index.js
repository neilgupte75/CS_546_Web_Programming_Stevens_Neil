module.exports = {
  users: require("./users"),
  posts: require("./posts")
};
