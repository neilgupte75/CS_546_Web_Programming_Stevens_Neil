# Lecture 8
An intro to MongoDB