let aboutInfo=()=>{
    let about={
        "name": "Neil Gupte",
        "cwid": "10445674",
        "biography": "I am a graduate student enrolled in the Stevens Institute of Technology for the term of Fall 2019.I am pursuing my Master in Computer Science.\nHaving completed my bachelors in computer engineering from India in the year 2018 I felt the urge to learn more and delve deeper into the nitty-gritty of areas of my interest which was the primary reason for opting to do masters.\n",
        "favoriteShows": ["The X files", "Game Of Thrones", "The Office", "The Elementary", "Sherlock","The Killing"],
        "hobbies": ["Playing Soccer", "Playing Table Tennis", "Playing multiplayer Games","Listening to Music"]
      }
    return about;
}
module.exports={aboutInfo};