let eduInfo=()=>{
    let edu=[
        {
            "schoolName": "Stevens Institute Of Technology",
            "degree": "Master of Computer Science",
            "favoriteClass": "CS 546 Web Programming",
            "favoriteMemory": "Freezing Winds near the Howe Center"
        },
        {
            "schoolName": "Savitribai Phule Pune University",
            "degree": "Bachelor of Computer Engineering",
            "favoriteClass": "Database Management Systems",
            "favoriteMemory": "Convocation Ceremony was awesome"
        },
        {
            "schoolName": "Abasaheb Garware College",
            "degree": "High School Diploma",
            "favoriteClass": "Biology",
            "favoriteMemory": "Vice Principal Khanvilkar was phenomenol"
        }
    ]
    return edu;

}
module.exports={eduInfo};