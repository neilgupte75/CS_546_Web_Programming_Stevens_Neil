const userData = require("./people");

module.exports = {
  users: userData
}